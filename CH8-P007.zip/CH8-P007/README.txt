SBL 1.0 resolved page rendering package
Render target: CH8-P007
Entry file: CH8-P007.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/SRA-production-sheet.png
  Assets/Zorna-canonical-character-specification(1).txt
  Assets/Zorna-character-sheet.png
  Assets/Character sheets Year 1/Ren Character Sheet.png
  Assets/Zorna-expression-sheet.png

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
