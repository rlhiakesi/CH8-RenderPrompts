SBL 1.0 resolved page rendering package
Render target: CH8-P017
Entry file: CH8-P017.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Midori-Age-11-Canonical-Character-Specification-v2.txt
  Assets/Takeshi-character-reference-sheet.png
  Assets/Aokawa-Temple-Interior-production-sheet.png
  Assets/Character sheets Year 1/Yui Character sheet.png
  Assets/Character sheets Year 1/Aiko Character Sheet.png
  Assets/Aokawa-Temple-Exterior-production-sheet.png
  Assets/Aokawa-Village-production-sheet.png
  Assets/Takeshi-expression-sheet.png
  Assets/Character sheets Year 1/Hana Character Sheet.png
  Assets/Character sheets Year 1/Ren Character Sheet.png
  Assets/Midori-age11-expression-sheet.png
  Assets/Takeshi-Canonical-Character-Specification.txt
  Assets/Midori-age11-character-reference-sheet.png

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
