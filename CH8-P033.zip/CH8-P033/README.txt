SBL 1.0 resolved page rendering package
Render target: CH8-P033
Entry file: CH8-P033.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Aokawa-Temple-Interior-production-sheet.png
  Assets/Aokawa-Temple-Exterior-production-sheet.png
  Assets/Character Sheets Year 3/Ren Character sheet Year 3.png
  Assets/Character Sheets Year 3/Midori age 13.png

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
