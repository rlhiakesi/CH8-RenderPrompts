SBL 1.0 resolved page rendering package
Render target: CH8-P049
Entry file: CH8-P049.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Takeshi-expression-sheet.png
  Assets/Truk-character-reference-sheet.png
  Assets/Character Sheets Year 3/Midori age 13.png
  Assets/Truk-expression-sheet.png
  Assets/Character Sheets Year 3/Ren Character sheet Year 3.png
  Assets/Aokawa-Village-production-sheet.png
  Assets/Takeshi-Canonical-Character-Specification.txt
  Assets/Takeshi-character-reference-sheet.png
  Assets/Truk-canonical-character-specification.txt

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
