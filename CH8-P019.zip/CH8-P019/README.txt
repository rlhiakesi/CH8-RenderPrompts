SBL 1.0 resolved page rendering package
Render target: CH8-P019
Entry file: CH8-P019.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Aokawa-Temple-Exterior-production-sheet.png
  Assets/Aokawa-Village-production-sheet.png
  Assets/Character sheets Year 1/Yui Character sheet.png
  Assets/Takeshi-Canonical-Character-Specification.txt
  Assets/Takeshi-expression-sheet.png
  Assets/Aokawa-Temple-Interior-production-sheet.png
  Assets/Takeshi-character-reference-sheet.png
  Assets/Character sheets Year 1/Aiko Character Sheet.png
  Assets/Character sheets Year 1/Ren Character Sheet.png
  Assets/Character sheets Year 1/Hana Character Sheet.png

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
