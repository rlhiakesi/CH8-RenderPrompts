SBL 1.0 resolved page rendering package
Render target: CH8-P010
Entry file: CH8-P010.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Midori-age11-character-reference-sheet.png
  Assets/Takeshi-Canonical-Character-Specification.txt
  Assets/Midori-Age-11-Canonical-Character-Specification-v2.txt
  Assets/VillageChief-Canonical-Character-Specification.txt
  Assets/Midori-age11-expression-sheet.png
  Assets/Midori-House-production-sheet.png
  Assets/Character sheets Year 1/Ren Character Sheet.png
  Assets/Village-Chief-expression-sheet.png
  Assets/Takeshi-character-reference-sheet.png
  Assets/Takeshi-expression-sheet.png
  Assets/Aokawa-Village-production-sheet.png
  Assets/Village-Chief-character-reference-sheet.png

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
