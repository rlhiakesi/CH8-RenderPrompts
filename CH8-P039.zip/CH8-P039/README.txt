SBL 1.0 resolved page rendering package
Render target: CH8-P039
Entry file: CH8-P039.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Character Sheets Year 3/Ren Character sheet Year 3.png
  Assets/Aokawa-Village-production-sheet.png
  Assets/Character Sheets Year 3/Aiko Character Sheet Year 3.png
  Assets/Character Sheets Year 3/Saburo Character Sheet, Year 3.png
  Assets/Truk-character-reference-sheet.png
  Assets/Truk-expression-sheet.png
  Assets/Truks-Carriage-Production-Sheet.png
  Assets/Character Sheets Year 3/Midori age 13.png
  Assets/Aokawa-Shrine-Attendant-Costume-Sheet.png
  Assets/Truk-canonical-character-specification.txt

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
